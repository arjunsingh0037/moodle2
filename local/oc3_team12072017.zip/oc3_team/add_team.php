<?php
/**
 * OC3 Team add team page
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */

require_once('../../config.php');
require_once('add_team_form.php');
require_once($CFG->libdir . '/formslib.php');
require_login(0,false);
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_pagelayout('admin');
$PAGE->set_url($CFG->wwwroot . '/local/oc3_team/add_team.php');
$PAGE->requires->css('/styles.css');
$mform = new add_team_form();
$maxbytes = 500000;
if ($mform->is_cancelled()){
    redirect(new moodle_url('/local/oc3_team/view.php', array()));
} else if ($data = $mform->get_data()) {
		$teamrecord = new stdClass();
		$teamrecord->name = $data->name;
	    $teamrecord->about = $data->about;
	    $teamrecord->address = $data->address;
	    $teamrecord->email = $data->email;
	    $teamrecord->fax = $data->fax;
	    $teamrecord->phone = $data->phone;
	    $teamrecord->medical = $data->medical;
	    $teamrecord->coach = $data->coach;
	    $teamrecord->teamleader = $data->teamleader;
	    $teamrecord->groupid = $data->group;
	    $teamrecord->status = $data->status;
	    $teamrecord->timemodified = time();
	    $teamrecord->profile_image = $data->profile_image;
	    $teamrecord->action_image = $data->action_image;

	    $newteam = $DB->insert_record('local_oc3_team', $teamrecord, true);
	    file_save_draft_area_files($data->profile_image, $context->id, 'local_oc3_team', 'content',
    	$data->profile_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
    	file_save_draft_area_files($data->action_image, $context->id, 'local_oc3_team', 'content',
    	$data->action_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
    	if($newteam){
    		redirect(new moodle_url('/local/oc3_team/view.php', array()),get_string('success','local_oc3_team'));
    	} 
	   	    
}
$title = get_string('addteam', 'local_oc3_team');
$PAGE->set_title($title);
$PAGE->set_heading($title);
$PAGE->navbar->add($title);
echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
