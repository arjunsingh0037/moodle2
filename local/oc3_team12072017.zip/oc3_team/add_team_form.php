<?php
/**
 * OC3 Team add team form
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */

require_once($CFG->libdir.'/formslib.php');
require_once($CFG->dirroot.'/local/oc3_team/lib.php');
class add_team_form extends moodleform {

    function definition() {
        global $CFG,$DB,$USER;
        $mform  = $this->_form;
        $siteusers = array();
        $group = array();
        $users = $DB->get_records('user');
        unset($users[1]);
        unset($users[2]);
        foreach ($users as $user) {
            $siteusers[$user->id] = $user->firstname.' '.$user->lastname;
        }
        $teams = $DB->get_records('groups');
        foreach ($teams as $team) {
            $group[$team->id] = $team->name;
        }
        $status = array(get_string('inactive','local_oc3_team'),get_string('active','local_oc3_team'));
        $mform->addElement('header', 'generalhdr', get_string('addteaminfo','local_oc3_team'));

        $mform->addElement('text', 'name', get_string('name','local_oc3_team'));
        $mform->setDefault('name', null);
        $mform->setType('name', PARAM_NOTAGS);
        $mform->addRule('name', 'required', 'required', null, 'client');
        $mform->addHelpButton('name','name','local_oc3_team');
    
        $mform->addElement('text', 'email', get_string('email','local_oc3_team'));
        $mform->setDefault('email', null);
        $mform->setType('email', PARAM_NOTAGS);
        $mform->addRule('email', 'required', 'required', null, 'client');
        $mform->addHelpButton('email','email','local_oc3_team');

        $mform->addElement('text', 'fax', get_string('fax','local_oc3_team'));
        $mform->setDefault('fax', null);
        $mform->setType('fax', PARAM_NOTAGS);
        $mform->addHelpButton('fax','fax','local_oc3_team');

        $mform->addElement('text', 'phone', get_string('phone','local_oc3_team'));
        $mform->setDefault('phone', null);
        $mform->setType('phone', PARAM_NOTAGS);
        $mform->addRule('phone', 'required', 'required', null, 'client');
        $mform->addHelpButton('phone','phone','local_oc3_team');

        $mform->addElement('select', 'coach', get_string('coach','local_oc3_team'),$siteusers);
        $mform->addHelpButton('coach','coach','local_oc3_team');

        $mform->addElement('select','teamleader',get_string('teamleader','local_oc3_team'),$siteusers);
        $mform->addHelpButton('teamleader','teamleader','local_oc3_team');

        $select = $mform->createElement('select', 'group',get_string('group','local_oc3_team'));
        foreach ($group as $id => $value) {
            $groupid = $DB->get_record('local_oc3_team',array('groupid'=>$id));
            if ($groupid) {
                $select->addOption($value, $id, array('disabled' => 'disabled'));
            } else {
                $select->addOption($value, $id);
            }
        }
        $mform->addElement($select);
        $mform->addRule('group', 'required', 'required', null, 'client');
        $mform->addHelpButton('group','group','local_oc3_team');

        $mform->addElement('select', 'status', get_string('status','local_oc3_team'),$status);
        $mform->addHelpButton('status','status','local_oc3_team');

        $mform->addElement('filemanager', 'profile_image', get_string('profile_image', 'local_oc3_team'), null, array('subdirs' => false, 'maxbytes' => '10MB', 'accepted_types' => '*', 'maxfiles' => 1));

        $mform->addElement('filemanager', 'action_image', get_string('action_image', 'local_oc3_team'), null, array('subdirs' => false, 'maxbytes' => '10MB', 'accepted_types' => '*', 'maxfiles' => 1));

        $mform->addElement('htmleditor','about',get_string('about','local_oc3_team'));
        $mform->setType('about', PARAM_RAW);
        $mform->addHelpButton('about','about','local_oc3_team');

        $mform->addElement('htmleditor', 'address', get_string('address','local_oc3_team'));
        $mform->setDefault('address', null);
        $mform->setType('address', PARAM_RAW);
        $mform->addHelpButton('address','address','local_oc3_team');

        $mform->addElement('htmleditor','medical',get_string('medical','local_oc3_team'));
        $mform->setType('medical', PARAM_RAW);
        $mform->addHelpButton('medical','medical','local_oc3_team');

        $this->add_action_buttons();
    }

    public function validation($data, $files) {
        // $errors = parent::validation($data, $files);
        
        // $fax = $data['fax'];
        // $phone = $data['phone'];

        // if( !is_numeric($fax) && !is_int($fax) ) {
        //     $errors[$fax] = get_string('error_invalid_fax', 'local_oc3_team');
        // }
        // if( !is_numeric($phone) && !is_int($phone) ) {
        //     $errors[$phone] = get_string('error_invalid_phone', 'local_oc3_team');
        // }
        // return $errors;
    }
}
