<?php
/**
 * OC3 Team edit team page
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */


require_once('../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once('edit_team_form.php');


$id = required_param('id',PARAM_INT);
$general = $DB->get_record('local_oc3_team', array('id' => $id)) ;
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_pagelayout('admin');
$PAGE->set_url($CFG->wwwroot . '/local/oc3_team/edit_team.php');
$PAGE->requires->css('/styles.css');
$mform = new edit_team_form(new moodle_url($CFG->wwwroot .'/local/oc3_team/edit_team.php',array('id'=>$id)));
$maxbytes = 500000;
$draftitemid1 = file_get_submitted_draft_itemid('profile_image');
file_prepare_draft_area($draftitemid1, $context->id, 'local_oc3_team', 'content',
        $general->profile_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
$general->profile_image = $draftitemid1; 

$draftitemid2 = file_get_submitted_draft_itemid('action_image');
$one = file_prepare_draft_area($draftitemid2, $context->id, 'local_oc3_team', 'content',
        $general->action_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
$general->action_image = $draftitemid2; 


$mform->set_data($general);
if ($mform->is_cancelled()) {
    redirect(new moodle_url('/local/oc3_team/view.php', array()));
}else if($data = $mform->get_data()) {
		$generalupd = new stdClass();
		$generalupd->id = $general->id;
		$generalupd->name = $data->name;
	    $generalupd->about = $data->about;
	    $generalupd->address = $data->address;
	    $generalupd->email = $data->email;
	    $generalupd->fax = $data->fax;
	    $generalupd->phone = $data->phone;
	    $generalupd->medical = $data->medical;
	    $generalupd->coach = $data->coach;
	    $generalupd->teamleader = $data->teamleader;
	    $generalupd->status = $data->status;
	    $generalupd->timemodified = time();
	    $generalupd->profile_image = $data->profile_image;;
	    $generalupd->action_image = $data->action_image;	
	    $generalupdate = $DB->update_record('local_oc3_team', $generalupd);
	    
	    file_save_draft_area_files($data->profile_image, $context->id, 'local_oc3_team', 'content',
    	$data->profile_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
    	file_save_draft_area_files($data->action_image, $context->id, 'local_oc3_team', 'content',
    	$data->action_image, array('subdirs' => 0, 'maxbytes' => $maxbytes, 'maxfiles' => 1));
		if($generalupdate){
			redirect(new moodle_url('/local/oc3_team/view.php', array()),get_string('updated','local_oc3_team'));
		}
}	
$title = get_string('editteam', 'local_oc3_team');
$PAGE->set_title($title);
$PAGE->set_heading($title);
$PAGE->navbar->add($title);
echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
?>
