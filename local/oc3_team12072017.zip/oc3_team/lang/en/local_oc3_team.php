<?php

/**
 * OC3 Team Language File
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */
$string['pluginname'] = 'OC3 Team';
$string['plugin'] = 'OC3 Teamy';
$string['indexpage'] = 'OC3 Team';
$string['pagetitle'] = 'OC3 Team';
$string['pagetitleteamlist'] = 'OC3 Team List';
$string['pagetitleview'] = 'My OC3 Team';

$string['pageheader'] = 'OC3 Team';
$string['oc3_team_settings'] = 'General Health Center Settings';
$string['oc3_team_home_status_settings'] = 'Home Status Settings';
$string['name'] = 'Health Center Name';
$string['name_help'] = 'Description about health center goes here';
$string['myteam_title'] = 'My Team';
$string['teammembers'] = 'Team Members';
$string['teammembers_help'] = 'Description about Team Members goes her';
$string['teamleader'] = 'Team Leader';
$string['teamleader_help'] = 'Description about Team Leader goes her';
$string['coach'] = 'Coach Name';
$string['coach_help'] = 'Description about Coach goes her';
$string['group'] = 'Group';
$string['group_help'] = 'Description about group goes her';
$string['health_center_photo'] = 'Health Center Photo';
$string['health_center_photo_help'] = 'Description about Health Center Photo goes here';
$string['about'] = 'About Health Center';
$string['about_help'] = 'Description about Health Center';
$string['status'] = 'About Status';
$string['status_help'] = 'Description about status of teams either active or inactive';
$string['address'] = 'Health Center Address';
$string['address_help'] = 'Description about Health Center address goes here';
$string['medical'] = 'Patient Centered Medical';
$string['medical_help'] = 'Description about Patient Centered Medical goes here';
$string['ecm_report'] = 'Electronic Medical Record';
$string['ecm_report_help'] = 'Description about lectronic Medical Record goes here';
$string['phone'] = 'General Phone';
$string['phone_help'] = 'Description about General Phone goes here';
$string['fax'] = 'General Fax';
$string['fax_help'] = 'Description about General Fax goes here';
$string['email'] = 'General Email Address';
$string['email_help'] = 'Description about General Email Address goes here';
$string['msgtl'] = 'Message the Team<br>Leader';
$string['msgcoach'] = 'Message the OC3<br>Coach';
$string['hasmsg'] = 'Team awesome has messages';
$string['inmsg'] = 'Incoming messages';
$string['groupmembers'] = 'Everyone on Team Awesome';
$string['groupaction'] = 'Team Awesome in action';

$string['upload'] = 'Upload images';
$string['continue'] = 'continue';
$string['waitingmsg'] = 'You are not added to any team.Please wait till administrator adds you any of the teams available on site.';
$string['teamnotactive'] = 'Your team is currently not active. Please come back later.';
$string['teamnotexisting'] = 'The team does not exists in our database.';

//for teamlisting page
$string['slno'] = 'Sl No.';
$string['listteamname'] = 'Team Name';
$string['listemail'] = 'Email';
$string['listfax'] = 'Fax';
$string['listphone'] = 'Phone';
$string['listcoach'] = 'Coach';
$string['listteamleader'] = 'Team Leader';
$string['liststatus'] = 'Status';
$string['listaction'] = 'Action';
$string['norecordfound'] = 'No records found';

$string['addteaminfo'] = 'Add Team Information';
$string['editteaminfo'] = 'Edit Team Information';
$string['addteam'] = 'Add team';
$string['deleteteam'] = 'Delete team';
$string['editteam'] = 'Edit team';
$string['showteam'] = 'Showing all teams';
$string['active'] = 'Active';
$string['inactive'] = 'In-active';
$string['teamlist'] = 'Team Lists';

//validation error messages
$string['error_invalid_fax'] = 'Invalid fax number';
$string['error_invalid_phone'] = 'Invalid phone number';
$string['success'] = 'Team has been added successfully';
$string['updated'] = 'Team records has been updated successfully';
$string['fail'] = 'Team couldn\'t be added';

$string['profile_image'] = 'Profile Image';
$string['action_image'] = 'Action Images';

//acccomplishment strings
$string['legacyaccom'] = 'Latest Accomplishments';
$string['legacygotmsg'] = 'have got a ';
$string['legacyhavecmpl'] = 'have completed ';
$string['nofeeds'] = 'No recent accomplishments';
$string['siteevent'] = 'has one upcoming site event';
$string['courseevent'] = 'has one upcoming course event';
$string['teamhavecmpl'] = 'has completed one task';
$string['teammessage'] = 'Your team';

