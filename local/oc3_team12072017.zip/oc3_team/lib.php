<?php

/**
 * OC3 Team Library File
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */
 function local_oc3_team_extend_navigation(global_navigation $nav) {
    global $CFG;
        $coursename = get_string('pluginname','local_oc3_team');
        $url = '#';
        $flat = new flat_navigation_node(navigation_node::create($coursename, $url), 0);
        $nav->add_node($flat);
        $abc = $nav->add(get_string('myteam_title','local_oc3_team'), $CFG->wwwroot.'/local/oc3_team/view.php'); 
        $abc->showinflatnavigation = true;
}


function local_oc3_team_pluginfile($course, $birecord_or_cm, $context, $filearea, $args, $forcedownload, array $options=array()) {
    global $DB, $CFG;

    if ($context->contextlevel != CONTEXT_SYSTEM) {
        send_file_not_found();
    }

    if ($context->get_course_context(false)) {
    } else if ($CFG->forcelogin) {
    } else {
        $parentcontext = $context->get_parent_context();
        if ($parentcontext->contextlevel === CONTEXT_COURSECAT) {
            $category = $DB->get_record('course_categories', array('id' => $parentcontext->instanceid), '*', MUST_EXIST);
            if (!$category->visible) {
                require_capability('moodle/category:viewhiddencategories', $parentcontext);
            }
        }
    }

    if ($filearea !== 'content') {
        send_file_not_found();
    }

    $fs = get_file_storage();

    $filename = array_pop($args);
    $filepath = '/';
    $itemid  = $args['0'];
   
    if (!$file = $fs->get_file($context->id, 'local_oc3_team', 'content', $itemid, $filepath, $filename) or $file->is_directory()) {
       
        send_file_not_found();
    }

    $managerobj = new \core\session\manager();
    $managerobj->write_close();
       
    send_stored_file($file, 60*60, 0, $forcedownload, $options);
}

function oc3_images($imageobj) {
    global $CFG;
    $fs = get_file_storage();
    $context = context_system::instance();
    $files = $fs->get_area_files($context->id, 'local_oc3_team', 'content', $imageobj, 'id', false);

    foreach ($files as $file) {
        $filename = $file->get_filename();

        if (!$filename <> '.') {
            $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), $file->get_filearea(), $imageobj, $file->get_filepath(), $filename);
            return $url;
        }
    }
}

  /************
  * this is for the news feed to be shown in the main content for legacy 
  * this is LATEST ACCOMPLISHMENTS in all pages
  *
  */

function legacy_feed_team(){
    global $CFG,$USER,$DB;
    $html = '';
    $count = 0;
    $msgarr1 = $msgarr2 = $msgarr3 = $msgarr4 = $msgarr5 = $msgarr0 = $msgarr11 = $msgarr22 = array();  
    if (isloggedin()) {
        $progessreport = legacy_accom_own_act_type3();

        if(legacy_accom_own_act_type3() != null){
            $count ++;
            foreach (legacy_accom_own_act_type3() as $key1 => $value1) {
              $msgarr1 [] = $value1; 
            }  
        }
        if(legacy_accom_own_act_type1() != null){
            $count++;
            foreach (legacy_accom_own_act_type1() as $key2 => $value2) {
                $msgarr2 [] = $value2; 
            }
        }
        if(legacy_accom_own_act_type4() != null){
            $count ++;
            foreach (legacy_accom_own_act_type4() as $key4 => $value4) {
                $msgarr4 [] = $value4;
            }
        }
        if(legacy_accom_own_act_type2() != null){
            $count ++;
            foreach (legacy_accom_own_act_type2() as $key5 => $value5) {
                $msgarr5 [] = $value5;
            }
        }
    }


    if($count == 0){
        $micon = $CFG->wwwroot.'/local/oc3_team/pix/nofeeds.png';
        $mtext =  get_string('nofeeds','local_oc3_team');
        $html .= message_feed($micon,$mtext);
    }
    $msgarr11 = array_merge($msgarr1,$msgarr2);
    $msgarr22 = array_merge($msgarr4,$msgarr11);
    $msgarr33 = array_merge($msgarr5,$msgarr22);
    //print_object($msgarr22);
    foreach($msgarr33 as $k => $d) {
      $msgarr0[$k] = $d['time'];
    }
    array_multisort($msgarr0, SORT_DESC, $msgarr33);
    //print_object($msgarr22);
    foreach ($msgarr33 as $msgval) {
        if($msgval['type'] == 'message'){
            $micon = $CFG->wwwroot.'/local/oc3_team/pix/msg.png';
            $mtext =  $USER->firstname.' '.$USER->lastname.' '.get_string('legacygotmsg','local_oc3_team').' '.$msgval['subject'];
        }else if($msgval['type'] == 'event'){

            $micon = $CFG->wwwroot.'/local/oc3_team/pix/event.png';
            $mtext =  $USER->firstname.' '.$USER->lastname.' '.get_string('legacyhavecmpl','local_oc3_team').' '.$msgval['subject'];

        }else if($msgval['type'] == 'siteevent'){
            $micon = $CFG->wwwroot.'/local/oc3_team/pix/siteevents.png';
            $mtext =  $USER->firstname.' '.$USER->lastname.' '.get_string('siteevent','local_oc3_team').' '.$msgval['name'].' ('.$msgval['date'].')';
        }else if($msgval['type'] == 'courseevent'){
            $micon = $CFG->wwwroot.'/local/oc3_team/pix/upcoming.png';
            $modid = $DB->get_record('modules',array('name'=>$msgval['modulename']));
            $cm = $DB->get_record('course_modules',array('course'=>$msgval['courseid'],'instance'=>$msgval['instance'],'module'=>$modid->id));
            $modlink = html_writer::tag('a', $msgval['name'],array('href' => new moodle_url($CFG->wwwroot.'/mod/'.$msgval['modulename'].'/view.php?id='.$cm->id)));
            $mtext =  $USER->firstname.' '.$USER->lastname.' '.get_string('courseevent','local_oc3_team').' '.$modlink.' ('.$msgval['date'].')';
        }else if($msgval['type'] == 'teamevent'){
            $micon = $CFG->wwwroot.'/local/oc3_team/pix/teamevent.png';
            $teamid = $DB->get_record('groups_members',array('userid'=>$USER->id));
            $teamname = $DB->get_record('local_oc3_team',array('groupid'=>$teamid->groupid));
            $teamlink = html_writer::tag('a', $teamname->name,array('href' => new moodle_url($CFG->wwwroot.'/local/oc3_team/view.php?id='.$teamid->groupid)));
            $mtext =  get_string('teammessage','local_oc3_team').' '.$teamlink.' '.get_string('teamhavecmpl','local_oc3_team').' '.$msgval['subject'];
        }
        $html .= message_feed($micon,$mtext);
    }
    return $html;
    
}
    /*Gives the list of activities/tasks completed by the loggedin user 
    * Arjun for legacy beta
    * This is type 1 accomplishments where user completion is shown
    */
  
function legacy_accom_own_act_type1() {
    global $CFG, $DB, $USER;
    $myenrolledcourses = enrol_get_my_courses();
    $allcourseactivities = array();
    foreach ($myenrolledcourses as $myenrolledcourse) {
        $i = 1;
        $cmplstates = get_activity($myenrolledcourse->id,true,true);
        $imrsrc = $CFG->wwwroot.'/local/oc3_team/pix/event.png';
        $html = '';
        $eventarray = $eventarray2 = array();
        foreach ($cmplstates['activity'] as $cmplstate) {
            $report1text = '';
            if ($cmplstate['completionstate'] == 1) {
            $report['name'] = $cmplstate['name'];
            $viewlink = '<a href='.$CFG->wwwroot.'/mod/'.$cmplstate['type'].'/view.php?id='.$cmplstate['id'].'>'.$report['name'].'</a>';
            $eventarray [] = array(
                                'id' => $cmplstate['id'],
                                'subject' => $viewlink,
                                'user' => $cmplstate['user'],
                                'time' => $cmplstate['timemodified'],
                                'type' => 'event'
                                );  
            }
        }
        $allcourseactivities [] = $eventarray;      
    }
    foreach ($allcourseactivities as $key => $allcourseact) {
        $eventarray2 = array_merge($eventarray2,$allcourseact);
    }
    return $eventarray2;   
}
  
  /*Gives the list of activities/tasks completed by the TEAM
  * Mihir for legacy beta
  * This is type 2 activities/tasks completed by the TEAM
  */
  
function legacy_accom_own_act_type2() { 
    global $CFG, $DB, $USER;
    $memberarray = $comparray = $comparray2 = $comparray3 = $team_completion_acts =array();
    $myenrolledcourses = enrol_get_my_courses();
    $myteamid = $DB->get_record('groups_members',array('userid'=>$USER->id));
    $memberids = $DB->get_records('groups_members',array('groupid'=>$myteamid->groupid));
    foreach ($memberids as $member) {
        $memberarray[] = $member->userid;
    }
    $members = count($memberarray);
    if($myenrolledcourses){
        foreach ($myenrolledcourses as $key => $myenrolledcourse) {
            $modstates = get_activity($myenrolledcourse->id,true,true);
            $count = 0;
            foreach ($modstates['activity'] as $modstate) {
                foreach ($memberarray as $mem) {
                    $completed = $DB->get_record('course_modules_completion',array('coursemoduleid' => $modstate['id'],'userid'=>$mem));
                    if($completed){
                        $comparray[$completed->coursemoduleid][]= $mem;                    
                    }                
                }
            }
        }
        foreach ($comparray as $key11 => $value11) {
            $comparray2[$key11] = count($value11); 
        }
        foreach ($comparray2 as $key22 => $value22) {
            if($members == $value22){
                $crsmod = $DB->get_record('course_modules',array('id'=>$key22));
                $modname = $DB->get_record('modules',array('id'=>$crsmod->module));
                $instancename = $DB->get_record($modname->name,array('id'=>$crsmod->instance));
                $viewlink = '<a href='.$CFG->wwwroot.'/mod/'.$modname->name.'/view.php?id='.$key22.'>'.$instancename->name.'</a>';
                $modlasttime = $DB->get_records('course_modules_completion',array('coursemoduleid'=>$key22));
                foreach ($modlasttime as $mk => $mvalue) {
                    $lasttime[] = $mvalue->timemodified;
                }
                $team_completion_acts [] = array(
                                                'id' => $key22,
                                                'subject' => $viewlink,
                                                'time' => end($lasttime),
                                                'type' => 'teamevent'
                                                );  
            }   
        }    
    }
    return $team_completion_acts;  
}

  
  /*Gives the list of messages received 
  * Mihir for legacy beta
  * This is type 3 messages received
  */
  
function legacy_accom_own_act_type3() {    
    global $CFG, $DB, $USER, $COURSE;
    $get_message = $DB->get_records_sql("Select id, useridfrom, subject, timecreated from {message} where useridto = $USER->id and component='moodle'");
    $html = '';
    $messagearray = array();
    $imrsrc2 = $CFG->wwwroot.'/local/oc3_team/pix/msg.png';
    foreach ($get_message as $message) {
        $msgurl = html_writer::tag('a', $message->subject,array('href' => new moodle_url($CFG->wwwroot.'/message/index.php?user='.$USER->id.'&id='.$message->useridfrom)));
        $messagearray [] = array(
                    'id' => $message->id,
                    'from' => $message->useridfrom,
                    'subject' => $msgurl,
                    'time' => $message->timecreated,
                    'type' => 'message'
                    );
    }
    return $messagearray;
}

  /*Gives the list of upcoming events on site and in user's courses
  * Arjun for legacy beta
  */
  
function legacy_accom_own_act_type4() {    
    global $CFG;
    require_once($CFG->dirroot.'/calendar/lib.php');
    $siteeventarray = array();
    $days = 50;
    $howmany = 50;
    $events = calendar_get_upcoming(0,0,0,$days,$howmany);
    foreach ($events as $ek => $event) {
        if($event->courseid != 0 && $event->visible == 1){
            if($event->courseid == 1){
                $type = 'siteevent';
            }else{
                $type = 'courseevent';
            }
            $siteeventarray [] = array(
                            'id' => $event->id,
                            'name' => $event->name,
                            'courseid' => $event->courseid,
                            'modulename' => $event->modulename,
                            'instance' => $event->instance,
                            'eventtype' => $event->eventtype,
                            'actionurl' => $event->actionurl,
                            'time' => $event->timestart,
                            'date' => $event->time,
                            'type' => $type
                            );
        }
    }
    //print_object($siteeventarray);
    return $siteeventarray;
}
 
  /**
     * Mihir for legacy beta
     * @param type $courseid
     * @param type $enable
     * @param type $bulk
     * @return boolean
     */
function get_activity($courseid = null, $enable = true, $bulk = false) {
        $std = new \stdClass();
        $std->id = $courseid;
        $cminfo = new \completion_info($std);
        if ($cminfo->is_enabled() != $enable) {
            return false;
        }
        $class = new \ReflectionClass("\completion_info");
        $property = $class->getProperty("course");
        $property->setAccessible(true);
        $list = $property->getValue($cminfo);
        $listarray = ['id' => $list->id, 'fullname' => $list->fullname, 'activity' => array()];
        foreach ($cminfo->get_activities() as $cm) {
            $listarray['activity'][] = array(
                'id' => $cm->id,
                'name' => $cm->name,
                'type' => $cm->modname,
                'completionstate' => $cminfo->get_data($cm, false, null, $cm)->completionstate,
                'timemodified' => $cminfo->get_data($cm, false, null, $cm)->timemodified,
                'user' => $cminfo->get_data($cm, false, null, $cm)->userid
            );
        }
        unset($cminfo);
        if ($bulk) {
            return $listarray;
        }
        return count($listarray['activity']);
}

function message_feed($icon,$text){
    global $CFG;
    $html = '';    
    $html .= html_writer::start_div('row py-10');
    $html .= html_writer::start_div('col-xs-1 col-lg-1 col-md-1');
    $html .='<div class="featured-box"><div class="featured-icon px-10" style="float:left"><img src='.$icon.' style="width: 30px"></div></div>';
    $html .= html_writer::end_div();  
    $html .= html_writer::start_div('col-xs-11 col-lg-11 col-md-11');
    $html .='<div class="featured-content px-10">
          <p>'.$text.'</p>
          </div>';
    $html .= html_writer::end_div();
    $html .= html_writer::end_div();
    return $html;
}