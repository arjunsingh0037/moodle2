<?php

/**
 * OC3 Team Renderer
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */
defined('MOODLE_INTERNAL') || die;
require_once $CFG->libdir . '/outputlib.php';
require_once $CFG->dirroot . '/local/oc3_team/lib.php';
class local_oc3_team_renderer extends plugin_renderer_base {

	function teamprofile($tid) {
		global $CFG,$USER,$DB,$OUTPUT;
		$html=$name=$about=$address=$mail=$fax=$phone=$medical=$teamleader=$group = '';
		if($tid == 0){
			$html .= $this->print_message('usernotadded');
		}else{
			$team = $DB->get_record('local_oc3_team',array('groupid'=>$tid));
			if(!$team){
				$html .= $this->print_message('teamnotexisting');
			}else{
				if($team->status == 1){
					$tl = $DB->get_record('user',array('id'=>$team->teamleader));
					if($tl){$tlname = $tl->firstname.' '.$tl->lastname;} 
					$context = context_system::instance();
					$profileimg = oc3_images($team->profile_image);	
					$actionimg = oc3_images($team->action_image);	
					$html .= '<div class="row">
						  <div class="col-sm-6 col-md-3">
						    <div class="thumbnail">
						      <img src="'.$profileimg.'" class="myteamimage">
						      <div class="caption">
						        <h3>'.$team->name.'</h3>
						        <p>'.$team->about.'</p>
						        <hr>
						        <p>'.$team->address.'</p>
						        <p>'.$team->medical.'</p>
						        <p>'.get_string('phone','local_oc3_team').' : '.$team->phone.'</p>
						        <p>'.get_string('fax','local_oc3_team').' : '.$team->fax.'</p>
						        <p>'.$team->email.'</p>
						        <hr>
						        <p>'.get_string('teamleader','local_oc3_team').' : '.$tlname.'</p>
						        <p><a href="'.$CFG->wwwroot.'/message/index.php?id='.$team->teamleader.'" class="btn btn-primary msg" role="button">'.get_string('msgtl','local_oc3_team').'</a></p>
						        <p><a href="'.$CFG->wwwroot.'/message/index.php?id='.$team->coach.'" class="btn btn-primary msg" role="button">'.get_string('msgcoach','local_oc3_team').'</a></p>';
					$html .='</div>
						    </div>
						  </div>
						  <div class="col-xs-6 col-md-6">
							    <div class="jumbotron">
								  <h3>Progress</h3>
								  <p>Lorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsumLorem ipsum</p>
								</div>
								<ul class="list-group">
								  <li class="list-group-item accomp-head"><h3>'.get_string('legacyaccom','local_oc3_team').'</h3></li>';
								  $html .= $OUTPUT->legacy_feed();
								$html .='</ul>
						  </div>
						  <div class="col-xs-6 col-md-3 everbody">
						  	<div class="teammembers">
						  		<h5 style="font-size: 14px;font-weight: bold;text-align: center;">'.get_string('groupmembers','local_oc3_team').'</h4>';
									$memberids = $DB->get_records('groups_members',array('groupid'=>$team->groupid));
									foreach ($memberids as $memberid) {
									  	$html .='<div class="col-xs-6 col-md-4">
												    <a href="'.$CFG->wwwroot.'/user/profile.php?id='.$memberid->userid.'">
												      <img class="uimgcircle" src="'.$CFG->wwwroot.'/user/pix.php?file=/'.$memberid->userid.'/f1.jpg"  height="50" width="50"/>
												    </a>
												  </div>';
									} 
							$html .='</div>
								  <div class="teaminaction">
								  	<h5 style="font-size: 14px;font-weight: bold;text-align: center;">'.get_string('groupaction','local_oc3_team').'</h4>
								    <p><img src="'.$profileimg.'" alt="..." class="myteamimage"></p>
								    <p><img src="'.$actionimg.'" alt="..." class="myteamimage"></p>
								 </div>   
							</div>';
				}else{
					$html .= $this->print_message('teamnotactive');
				}
			}
		}	
		return $html;
	}
	function teamlist() {
		global $CFG,$USER,$DB;
		$i=1;
		$table = new html_table();
		$table->head = (array) get_strings(array('slno','listteamname','listemail', 'listfax', 'listphone','listteamleader','listcoach','liststatus','listaction'),'local_oc3_team');
		$teams = $DB->get_records('local_oc3_team');
		if ($teams) {
        	foreach ($teams as $team) {
        		$tl = $DB->get_record('user',array('id'=>$team->teamleader));
				$teamleader = $tl->firstname.' '.$tl->lastname; 
				$ch = $DB->get_record('user',array('id'=>$team->coach));
				$coach = $ch->firstname.' '.$ch->lastname; 
				if($team->status == 1){
					$status = get_string('active','local_oc3_team');
				}else{
					$status = get_string('inactive','local_oc3_team');
				}
				$edit = '<a href="' . $CFG->wwwroot. '/local/oc3_team/edit_team.php?id='.$team->id.'">edit</a>';
	            $table->data[] = array(
	                $i,
	                $team->name,
	                $team->email,
	                $team->fax,
	                $team->phone,
	                $teamleader,
	                $coach,
	                $status,
	                $edit
	            );
	            $i++;
	        }
	    }else {
        	$table->data[] = array('','','<p class="norecords">'.get_string('norecordfound', 'local_oc3_team').'</p>','','','','','');
        }
        $html = html_writer::table($table);
		return $html;
	}
	function print_message($message){
		global $CFG,$USER;
		$msg='';
		if($message == 'usernotadded'){
			$message_text = get_string('waitingmsg','local_oc3_team');
		}else if($message == 'teamnotactive'){
			$message_text = get_string('teamnotactive','local_oc3_team');
		}else if($message == 'teamnotexisting'){
			$message_text = get_string('teamnotexisting','local_oc3_team');
		}
		$msg .= html_writer::start_div('row');
		$msg .= html_writer::start_div('col-sm-12 col-md-12');
		$msg .= html_writer::start_div('jumbotron');
		$msg .=html_writer::tag('h3', 'Notice', array('style' => 'text-align:center'));
		$msg .=html_writer::tag('p', $message_text, array('style' => 'text-align:center'));
		$msg .=html_writer::tag('a', get_string('continue','local_oc3_team'),
                 array('class'=>'continue','href' => new moodle_url($CFG->wwwroot.'/my')));
		$msg .= html_writer::end_div();
		$msg .= html_writer::end_div();					
		$msg .= html_writer::end_div(); 
		return $msg; 
	}

}