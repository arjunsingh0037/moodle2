<?php

/**
 * OC3 Team Settings File
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */
defined('MOODLE_INTERNAL') || die;
require_once $CFG->dirroot . '/local/oc3_team/lib.php';
global $CFG,$DB;
if ($hassiteconfig) {
	$ADMIN->add(
		'root',
		new admin_category(
			'oc3_team',
			get_string(
				'pluginname',
				'local_oc3_team'
			)
		)
	);
	$ADMIN->add(
		'oc3_team',
		new admin_externalpage(
			'oc3_teamsettings',
			get_string(
				'addteam',
				'local_oc3_team'
			),
			$CFG->wwwroot . '/local/oc3/add_team.php',
			'moodle/course:update'
		)
	);
	$ADMIN->add(
		'oc3_team',
		new admin_externalpage(
			'oc3_upload',
			get_string('teamlist','local_oc3_team'),
			$CFG->wwwroot . '/local/oc3_team/teamlist.php',
			'moodle/course:update'
		)
	);
}
