<?php

/**
 * OC3 Team
 * @author     Arjun Singh <arjunsingh@elearn10.com>
 * @package    local_oc3_team
 * @copyright  07/09/2016 lms of india
 * @license    http://lmsofindia.com/
 */
require_once('../../config.php');
require_login(0,false);
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('pagetitleview', 'local_oc3_team'));
$PAGE->set_heading(get_string('pageheader', 'local_oc3_team'));
$PAGE->set_url($CFG->wwwroot . '/local/oc3_team/view.php');
$PAGE->requires->css('/styles.css');
require_once $CFG->dirroot . '/local/oc3_team/lib.php';
// Get the renderer for this page
$renderer = $PAGE->get_renderer('local_oc3_team');
echo $OUTPUT->header();
echo $renderer->teamprofile();
$context = context_system::instance();
echo $OUTPUT->footer();
?>
